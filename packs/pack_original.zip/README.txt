Pack de animación de Rocksoup

Incluye: personaje explorador, jinete, burro gris, lobo, casas de aldea,
chamán, edificios del feudo, universidad, observatorio y unidades.

Cómo editar:
1. Abre los PNG manteniendo el mismo nombre y número de frames.
2. No cambies la estructura de carpetas.
3. Comprime de nuevo la carpeta con pack.json en la raíz.
4. Sube el ZIP desde Personalización y packs > Subir pack .zip.

Los sprites de animación usan _0.png, _1.png y _2.png.
Los edificios y unidades son una sola imagen PNG.
